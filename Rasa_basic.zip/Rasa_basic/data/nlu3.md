## intent:greet
- hey

## intent:restaurant_search
- I am hungry
- in [mubaim](location)
