## intent:greet
- Hey

## intent:restaurant_search
- I am looking for restaurants in [vizag]{"entity": "location", "value": "Vizag"}
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- more [than 700](price)

## intent:ask_to_send
- no
