## intent:greet
- hey

## intent:restaurant_search
- I am hungry.Look for restaurants
- in [mumbai]{"entity": "location", "value": "Mumbai"}
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- more [than 700](price)

## intent:ask_to_send
- no
