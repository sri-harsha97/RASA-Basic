## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- thanks
- thank you so much

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one
- bye bye

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- hi
- hi
- hello
- hola



## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I’m hungry. Looking out for some good restaurants
- I am looking for some restaurants in [New Delhi](location).
- Can you suggest some restaurants in [New Delhi](location).
- show me [chinese](cuisine) restaurants
- show me [chines](cuisine:chinese) restaurants in the [Delhi](location:New Delhi)
- Can you suggest some restaurants in [New Delhi](location).?
- Can you suggest some restaurants in [Bombay](location:Mumbai)?
- Can you suggest restaurants in [Amritsar](location)
- can you suggest some restaurants in [Aurangabad](location:aurangabad)
- show me some restaurants in [Chennai](location)
- cn you suggest some restaurants in [Bhopal](location)
- Can you suggest some restaurants in [Chandigarh](location).
- Ca you suggest some restaurants in [Bhubaneshwar](location)
- Cn you suggest some restaurants in [Coimbatore](location).
- can you suggest some restaurants in [Ludhiana](location)
- Search for some restaurants in [Secunderabad](location)
- search for some restaurants in [Ooty](location).
- Can you suggest some restaurants in [Agra](location).
- Can you suggest some restaurants in [Puducherry](location)
- Suggest some restaurants in [Puducherry](location)
- Are restaurents available in [Agra](location)
- are restaurents available in [Chennai](location)
- Are restaurents available in [Secunderabad](location)
- show me a [mexican](cuisine) place in the [centre](location)
- show me a [Italian](cuisine) place in the [centre](location)
- Can you suggest some restaurants in [New Delhi](location).
- i am looking for an [indian](cuisine) spot called olaolaolaolaola
- in [Gurgaon](location)
- in [dwlao](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [Chinese](cuisine:chinese)
- [chinese](cuisine)
- check [Lithuania](location)
- [mexican](cuisine)
- Can you suggest some restaurants in [New Delhi](location).
- Oh, sorry, in [Italy](location)
- in [delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [mexican indian fusion](cuisine)
- [central](location) [indian](cuisine) restaurant
- please help me to find restaurants in [Pune](location)
- Please find me a restaurantin [Bangalore](location)
- [Chinese](cuisine:chinese)
- show me restaurants
- find me at [Mumbai](location)
- I will prefer [Italian](cuisine)
- South Indian(cuisne)
- North Indian(cuisne)
- [Nashik](location)
- [Nasik](location)
- please find me [chinese](cuisine) restaurant in [delhi](location)
- can you find me a [chinese](cuisine) restaurant
- [Delhi](location)
- please find me a restaurant in [Ahmedabad](location)
- [Gurgaon](location)
- [Guwahati](location)
- What's a good place to eat Mexican food
- Find a restaurant for me where I can eat north indian
- Find a restaurant for me to eat mexican
- [Hyderabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore](location)
- please find me a restaurant in [Ahmedabad](location)
- please find me a restaurant in [New Delhi](location)
- Can you suggest some restaurants in [Allahabad](location).
- Can you suggest some restaurants in [Varanasi](location).
- Can you suggest some restaurants in [Vizag](location).
- [Agra](location)
- [Ahmedabad](location)
- at [Mysore](location)
- in [Chandigarh](location)
- Find some restaurants in [Pune](location)
- Find restaurants in [Mumbai](location)
- Get some info on restaurants in [calcutta](location:Kolkata)
- info in [trivandrum][location:Thiruvananthapuram]
- Find a restaurant for me to eat [Mexican](cuisine:mexican) at [Faridabad](location)
- I am hungry, find me some place to go eat [italian](cuisine) in [Goa](location)
- Would you find a [south indian](cuisine) restaurant for me in [Kozhikode](location)?
- A place to eat [chinese](cuisine) in [mysuru](location:Mysore)
- Get me some food quickly
- Pick some place for me to eat quickly
- Where can i get some food to eat
- i'm looking for a restaurant
- how can you help me find a restaurant
- pick a restaurant for me
- please find a restaurant for me
- look up for some restuarants 
- find me a [chinese](cuisine)
- [less than 300](price)
- [between 300 and 700](price)
- [greater than 700](price)
- [<300](price:less than 300)
- [>700](price:greater than 700)
- [american](cuisine)
- show m3 a [chines]{"entity": "cuisine", "value":"chinese"}
- in [Delhi]{"entity":"location", "value":"New Delhi"}
- it will be at [<300]{"entity": "price", "value": "less than 300"}
- I am looking for some restuarants in [Agra](location) with price [<300]{"entity": "price", "value": "less than 300"}
- I am looking for [mexican](cuisine) in [Jamshedpur](location) [between 300 and 700](price)
- in [Agra](location)
- in [Vizag](location)
- at [Chandigarh](location)
- I am looking for some restaurants in [Mumbaims](location)
- I am looking for some restaurants in [dilli](location)
- Okay. I want to eat [south indian](cuisine) in [Allahabaaad](location)
- Okay. Show me some [north indian](cuisine) restaurants in [PAsarayagraj](location)
- What's a good place to eat [mexican](cuisine) food in [Cjaandighar](location)
- I am looking for some restaurants in [Mumbaims](location)
- I am looking for some restaurants in [dilli](location)
## intent:ask_to_send
- [yes](response)
- [not required](response)
- [yes](response) please
- [not required](response) thank you
- [Yes](response:yes)
- [not required](response:no)
## intent:send_email
- can u mail me the information to [abcdefg123@abc.com](email)?
- can u mail to [test_1232@tes.com](email)?
- share some more restaurant names with me in this [pbc@abo.com](email)
- [abcdes.rgf@cvd.com](email)
- share this over [abve.sdsc@abc.com](email)
- share this information with me over [a1222edbc@abc.com](email)
- [abc@yahoo.com](email)
- [xyz@abc.co.in](email)
- [avdc.scdcs@gmail.com](email)
- [afeefefef12135@gmail.com](email)
- send me to this [absas@abc.com](email) address

## synonym:yes
- Yes
- yes please
- Sure
- sure
- please do 
- kindly send it to me
- Yes please

## synonym:not required
- No
- Not required
- no thank you
- No thank you
- no
## regex:email
- [a-zA-Z0-9+_.-]@[a-zA-Z0-9.-].[a-zA-Z]{2,5}

## synonym:Delhi
- New Delhi

## synonym:bangalore
- Bengaluru

## regex:greet
- hey[^\s]*

## regex:pincode
- [0-9]{6}
## synonym:chinese
- Chinese
- chinse
- chnese
- chiesee
- chins
- chine
## synonym:mexican
- Mexican
- mexcn
- mexican
- mxcn
- me
## synonym:american
- American
- american
- amcrn
- amrcn
## synonym:italian
- Italian
- itlian
- itlalian
- italian
- itli
- itlin
## synonym:south indian
- south-indian
- southindian
- South-indina
- South Indian
- south
- southindian
- South
## synonym:north indian
- north-indian
- northindian
- North-indina
- North Indian
- north
- North
## synonym:Bengaluru
- Bangalore
- bngalore
- bengalluru
- Bangalor
- bangalore
- bengaluru
## synonym:Delhi
- New Delhi
- Delhi NCR
- NewDelhi
- Dilli
- Dellhi
- newdelhi
- Newdelhi
- new delhi
- new Delhi
## synonym:Mumbai
- Bombay
- mumbai
- bombay
## synonym:Kolkata
- Calcutta
- kolkata
- kolkatta
- calcutta
- calcuta
## synonym:Chennai
- chennai
- madras
- Madras
## synonym:Hyderabad
- hyderabad
- Secunderabad
- secunderabad
- cyberabad
- Cyberabad
## synonym:Lucknow
- Lakhanpur
## synonym:Agra
- agra
## synonym:Mysore
- mysore
- mysuru
- Mysuru
## synonym Kochi
- kochi
- cochin
- Cochin
## synonym:Mangalore
- mangalore
- mangaluru
- Mangaluru
## synonym:Vizag
- visakhapatnam
- vizag
- Visakhapatnam
## synonym:Thiruvananthapuram
- thiruvananthapuram
- trivandrum
- Trivandrum
- Travancore
- travancore
## synonym:Vadodara
- vadodara
- Vadodra
- vadodra
## synonym:Jamshedpur
- jamshedpur
- Jamsedpur
- jamsedpur
## synonym:Amritsar
- amritsar
- Amratsar
- amratsar
## synonym:Chandigarh
- chandigarh
- Chandighar
- chandighar
## synonym:Allahabad
- prayagraj
- Prayagraj
- Allahabad
- allahabad
## synonym:Nashik
- nashik
## synonym:Nasik
- nasik
## synonym:Pondicherry
- pondicherry
- puducherry
- Puducherry

## synonym:less than 300
- <300,
- < 300
- less 300
- Less than 300
- Lower than 300
- 300 or less
- at 300 price
- At 300 price
## synonym:between 300 and 700
- bw 300 and 700,
- 300-700,
- bw 300 & 700,
- btw 300-700",
- between 300-700
- Between 300-700
- in range of 300 and 700
- at 300 and 700 cost
- at 300 and 700 price
- Betweem 300 and 700
## synonym:more than 700
- >700
- > 700
- mt 700
- greater than 700 price
- at 700 price
- At 700 price
- Greater than 700 price
- More than 700