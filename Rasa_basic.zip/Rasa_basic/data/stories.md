## complete path
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine       
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price":"less than 300"}    
    - slot{"price":"less than 300"}
    - action_search_restaurants 
 * ask_to_send{"response": "yes"}
    - slot{"response":"yes"}
    - action_check_response
    - slot{"check_resp":true}
 * send_email{"email":"abc@abc.com"}   
    - slot{"email": "abc@abc.com"}
    - action_send_mail   
    - utter_goodbye
    - export

## complete path 2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Delhi"}
    - slot{"location": "delhi"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine       
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price":"less than 300"}    
    - slot{"price":"less than 300"}
    - action_search_restaurants 
 * ask_to_send{"response": "not required"}
    - slot{"response":"not required"}
    - action_check_response
    - slot{"check_resp":false} 
    - utter_goodbye
    - export

## complete path 4
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Hyderabad"}
    - slot{"location": "Hyderabad"}
    - action_check_location
    - slot{"check_resp":true}
	- utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price":"more than 700"}
    - slot{"price":"more than 700"}
    - action_search_restaurants  
* ask_to_send{"response": "yes"}
    - slot{"response":"yes"}
    - action_check_response
* send_email{"email":"abc@abc.com"}   
    - slot{"email": "abc@abc.com"}
    - action_send_mail 
    - utter_sent   
* goodbye
    - utter_goodbye

## complete path 5
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price":"between 300 and 700"}
    - slot{"price":"more than 700"}
    - action_search_restaurants
    - slot{"location": "delhi"}  
 * ask_to_send{"response": "yes"}
    - slot{"response":"yes"}
    - action_check_response
 * send_email{"email":"abc@abc.com}   
    - slot{"email": "abc@abc.com"}
    - action_send_mail 
    - utter_sent  
    - utter_goodbye
    - export

## complete_path_6_location_not_found
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - action_check_location
    - slot{"check_resp":false}
    - utter_we_dont_operate

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - utter_ask_price
* restaurant_search{"price":"more than 300"}
    - slot{"price":"more than 700"}
    - action_search_restaurants
* ask_to_send{"response": "yes"}
    - slot{"response":"yes"}
    - action_check_response
* send_email{"email":"abc@abc.com"}   
    - slot{"email": "abc@abc.com"}
    - action_send_mail 
    - utter_sent  
    - utter_goodbye

   

## interactive_story_1_with_cuisine_and_location
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Vizag"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Vizag"}
    - action_check_location
    - slot{"check_resp":true}
    - action_search_restaurants
    - utter_ask_price
* restaurant_search{"price":"less than 300"}    
    - slot{"price":"less than 300"}
    - action_search_restaurants
* ask_to_send{"response": "yes"}
    - slot{"response":"yes"}
    - action_check_response
* send_email{"email":"abc@abc.com"}   
    - slot{"email": "abc@abc.com"}
    - action_send_mail 
    - utter_sent  
    - utter_goodbye
* affirm
    - utter_goodbye
    
    
## complete_search
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "mumbai","price":"less than 300"}
    - slot{"cuisine": "italian"}
    - slot{"location": "mumbai"}
    - slot{"location":"less than 300"}
    - action_check_location
    - slot{"check_resp":true}
    - action_search_restaurants    
* ask_to_send{"response": "yes"}
    - slot{"response":"yes"}
    - action_check_response
* email{"email":"abc@abc.com"}   
    - slot{"email": "abc@abc.com"}
    - action_send_mail 
    - utter_sent  
    - utter_goodbye
* affirm
    - utter_goodbye


## interactive_story_2_with_location_and_price
* greet
    - utter_greet
* restaurant_search{"location": "mumbai","price":"less than 300"}
    - slot{"location": "mumbai"}
    - slot{"location":"less than 300"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine  
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"} 
    - action_search_restaurants 
* ask_to_send{"response": "yes"}
    - slot{"response":"yes"}
    - action_check_response
* send_email{"email":"abc@abc.com"}   
    - slot{"email": "abc@abc.com"}
    - action_send_mail
    - utter_sent  
    - utter_goodbye
* affirm
    - utter_goodbye


## complete_path_email_not_required
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - utter_ask_price
* restaurant_search{"price":"more than 300"}
    - slot{"price":"more than 700"}
    - action_search_restaurants
* ask_to_send{"response": "not required"}
    - slot{"response":"not required"} 
    - action_check_response 
    - slot{"check_resp":false}
    - utter_goodbye
* affirm
    - utter_goodbye

## interactive_story_2_with_location_and_price_email_not_requrired
* greet
    - utter_greet
* restaurant_search{"location": "mumbai","price":"less than 300"}
    - slot{"location": "mumbai"}
    - slot{"location":"less than 300"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine 
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_search_restaurants
* ask_to_send{"response": "not required"}
    - slot{"response":"not required"}
    - action_check_response
    - slot{"check_resp":false}
    - utter_goodbye
* affirm
    - utter_goodbye


## complete_search_with_email_not_required
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "mumbai","price":"less than 300"}
    - slot{"cuisine": "italian"}
    - slot{"location": "mumbai"}
    - slot{"location":"less than 300"}
    - action_check_location
    - slot{"check_resp":true}
    - action_search_restaurants    
* ask_to_send{"response": "not required"}
    - slot{"response":"not required"} 
    - action_check_response 
    - slot{"check_resp":false}
    - utter_goodbye
* affirm
    - utter_goodbye


## complete_path_6_location_not_found_without greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - action_check_location
    - slot{"check_resp":false}
    - utter_we_dont_operate


## complete_path_email_not_required
* greet
    - utter_greet
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - utter_ask_price
* restaurant_search{"price":"more than 300"}
    - slot{"price":"more than 700"}
    - action_search_restaurants
* ask_to_send{"response": "not required"}
    - slot{"response":"not required"}  
    - action_check_response
    - slot{"check_resp":false}
    - utter_goodbye
* affirm
    - utter_goodbye


## complete path_with_location asked
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Delhi"}
    - slot{"location": "delhi"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine       
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price":"less than 300"}    
    - slot{"price":"less than 300"}
    - action_search_restaurants 
 * ask_to_send{"response": "not required"}
    - slot{"response":"not required"}
    - action_check_response
    - slot{"check_resp":false}
    - utter_goodbye
    - export    

## complete_path_6_location_not_found_with_email_not_required
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - action_check_location
    - slot{"check_resp":false}
    - export    


## interactive_story_2_with_location_and_price
* greet
    - utter_greet
* restaurant_search{"location": "mumbai","price":"less than 300"}
    - slot{"location": "mumbai"}
    - slot{"location":"less than 300"}
    - action_check_location
    - slot{"check_resp":false}
    - utter_we_dont_operate
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"} 
    - action_search_restaurants 
* ask_to_send{"response": "yes"}
    - slot{"response":"yes"}
    - action_check_response
* send_email{"email":"abc@abc.com"}   
    - slot{"email": "abc@abc.com"}
    - action_send_mail
    - utter_sent  
    - utter_goodbye
* affirm
    - utter_goodbye

## complete path with email not required
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine       
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price":"less than 300"}    
    - slot{"price":"less than 300"}
    - action_search_restaurants 
 * ask_to_send{"response": "not required"}
    - slot{"response":"not required"}
    - action_check_response
    - slot{"check_resp":false}
    - utter_goodbye
    - export

## complete path without question asked and email not required
* greet
    - utter_greet
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_check_location
    - slot{"check_resp":true}
    - utter_ask_cuisine       
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price":"less than 300"}    
    - slot{"price":"less than 300"}
    - action_search_restaurants 
 * ask_to_send{"response": "not required"}
    - slot{"response":"not required"}
    - action_check_response
    - slot{"check_resp":false}
    - utter_goodbye
    - export

