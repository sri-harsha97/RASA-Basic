from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import pandas as pd
import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

ZomatoData = pd.read_csv('zomato.csv')
ZomatoData = ZomatoData.drop_duplicates().reset_index(drop=True)
ZomatoData['price_range'] = ""
ZomatoData['cost'] = ZomatoData['Average Cost for two'].astype(int)
ZomatoData['Aggregate rating'] = ZomatoData['Aggregate rating'].astype(float)
WeOperate = ['New Delhi', 'Gurgaon', 'Noida', 'Faridabad', 'Allahabad', 'Bhubaneshwar', 'Mangalore', 'Mumbai', 'Ranchi', 'Patna', 'Mysore', 'Aurangabad', 'Amritsar', 'Puducherry', 'Varanasi', 'Nagpur', 'Vadodara', 'Dehradun', 'Vizag', 'Agra', 'Ludhiana', 'Kanpur', 'Lucknow', 'Surat', 'Kochi', 'Indore', 'Ahmedabad', 'Coimbatore', 'Chennai', 'Guwahati', 'Jaipur', 'Hyderabad', 'Bangalore', 'Nashik', 'Pune', 'Kolkata', 'Bhopal', 'Goa', 'Chandigarh', 'Ghaziabad', 'Ooty', 'Gangtok', 'Shimla']
WeOperate = [word.lower() for word in WeOperate]
## WeOperate = ZomatoData['City'].unique()
def get_pricerange(row):
	if row['cost'] < 300 :
		return 'less than 300'
	elif 300 <= row['cost'] & row['cost'] < 700:
		return 'between 300 and 700'
	else:
		return 'more than 700'

ZomatoData['price_range'] = ZomatoData.apply(get_pricerange, axis=1)
def RestaurantSearch(City,Cuisine,Price):
		if Price == None:
			TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (ZomatoData['City'].apply(lambda x: City.lower() in x.lower()))]
		elif Cuisine == None:
			TEMP = ZomatoData[(ZomatoData['City'].apply(lambda x: City.lower() in x.lower())) & (ZomatoData['price_range'].apply(lambda x: Price.lower() in x.lower()))]
		elif City == None:
			TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (ZomatoData['price_range'].apply(lambda x: Price.lower() in x.lower()))]
		else:
			TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (ZomatoData['City'].apply(lambda x: City.lower() in x.lower())) & (ZomatoData['price_range'].apply(lambda x: Price.lower() in x.lower()))]
		TEMP.sort_values(by=['Aggregate rating'],ascending=False,inplace=True)
		return TEMP[['Restaurant Name','Address','Average Cost for two','Aggregate rating']]

def ValidateLocation(location):
		if location.lower() in WeOperate:
			return True
		else:
			return False		

def sendmail(MailID,response):
	mail_content = response
	#The mail addresses and password
	sender_address = 'testbot6990@gmail.com'
	sender_pass = 'testbot@0909'
	receiver_address = MailID
	#Setup the MIME
	message = MIMEMultipart()
	message['From'] = sender_address
	message['To'] = receiver_address
	message['Subject'] = 'Restaurants'   #The subject line
	#The body and the attachments for the mail
	message.attach(MIMEText(mail_content, 'plain'))
	print(MailID)
	#Create SMTP session for sending the mail
	session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
	session.starttls() #enable security
	session.login(sender_address, sender_pass) #login with mail_id and password
	text = message.as_string()
	session.sendmail(sender_address, receiver_address, text)
	session.quit()
	return [SlotSet('response','none')]

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'

	def run(self, dispatcher, tracker, domain):
		#config={ "user_key":"f4924dc9ad672ee8c4f8c84743301af5"}
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		price = tracker.get_slot('price')
		results = RestaurantSearch(City=loc,Cuisine=cuisine,Price=price)
		response=""
		if results.shape[0] < 5:
				response= "We are not operational in your area yet!"	
		else:
				for restaurant in RestaurantSearch(loc,cuisine,price).iloc[:5].iterrows():
					restaurant = restaurant[1]
					response=response + F"Found {restaurant['Restaurant Name']} in {restaurant['Address']} has been rated {restaurant['Aggregate rating']}\n\n"
				response = response + "Do you want us to send top 10 restaurants on email?"
		dispatcher.utter_message(response)
		return [SlotSet('location',loc)]

class ActionSendMail(Action):
	def name(self):
		return 'action_send_mail'

	def run(self, dispatcher, tracker, domain):
		MailID = tracker.get_slot('email')
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		price = tracker.get_slot('price')	
		results = RestaurantSearch(City=loc,Cuisine=cuisine,Price=price)
		response="Hi,\n\n\n"
		response="Following are the restaurant details\n\n\n"
		for restaurant in RestaurantSearch(loc,cuisine,price).iloc[:10].iterrows():
					restaurant = restaurant[1]
					response=response + F"Found {restaurant['Restaurant Name']} in {restaurant['Address']} rated {restaurant['Aggregate rating']} with avg cost {restaurant['Average Cost for two']}\n\n"
		sendmail(MailID,response)

class Actionchecklocation(Action):
	def name(self):
		return 'action_check_location'

	def run(self, dispatcher, tracker, domain):
			location = tracker.get_slot('location')
			res = ValidateLocation(location)
			if res == False:
				dispatcher.utter_message("We do not operate in that area yet.Please check other location")
				return [SlotSet('check_resp',res)]
			else:
				return [SlotSet('check_resp',True)]	

class ActionCheckResponse(Action):
	def name(self):
		return 'action_check_response'

	def run(self, dispatcher, tracker, domain):
		response = tracker.get_slot('response')
		print("response here")
		print(response)
		if response == 'yes':
			dispatcher.utter_message("Please Enter your Email Address we will send it you right away!")
			return [SlotSet('check_resp',True)]		
		else:
			dispatcher.utter_message("Bye!")
			return [SlotSet('check_resp',True)]	


